<?php
namespace App\Services;

use App\Models\NroAccount;
use App\Models\NroAccountSnapshot;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class NroSnapshotService
{
    public function __construct(private NroCatalog $catalog) {}

    public static function cardItemPreviews(array $data): array
    {
        $previews = [];
        foreach (['equipped', 'bag', 'chest'] as $location) {
            $items = $data[$location] ?? [];
            $previews[$location] = [
                'count' => count($items),
                'items' => array_map(fn ($item) => Arr::only($item, ['templateId', 'iconId', 'name', 'quantity']), array_slice($items, 0, 6)),
            ];
        }
        return $previews;
    }

    public static function identity(array $item): array
    {
        $options = array_map(fn ($o) => ['optionId' => (int) $o['optionId'], 'param' => (int) $o['param']], $item['options'] ?? []);
        usort($options, fn ($a, $b) => [$a['optionId'], $a['param']] <=> [$b['optionId'], $b['param']]);
        return ['templateId' => (int) $item['templateId'], 'info' => $item['info'] ?? '', 'content' => $item['content'] ?? '', 'options' => $options];
    }

    public function ingest(NroAccount $account, array $payload): NroAccountSnapshot
    {
        $payload['completeness']['equipped'] ??= false;
        Validator::make($payload, [
            'schemaVersion' => 'required|integer|in:1', 'catalogVersion' => 'required|string|max:50',
            'snapshot' => 'required|array', 'snapshot.capturedAt' => 'required|date',
            'snapshot.character' => 'required|array', 'snapshot.character.id' => 'required|integer|min:1',
            'snapshot.character.name' => 'required|string|max:100',
            'completeness' => 'required|array', 'completeness.bag' => 'required|boolean', 'completeness.chest' => 'required|boolean', 'completeness.equipped'=>'required|boolean',
            'snapshot.currentTask' => 'nullable|array',
            'snapshot.currentTask.id' => 'sometimes|integer|min:-1|max:65535',
            'snapshot.currentTask.currentStep' => 'sometimes|integer|min:-1|max:255',
            'snapshot.currentTask.currentCount' => 'sometimes|integer|min:-1|max:2147483647',
            'snapshot.currentTask.name' => 'sometimes|string|max:1000',
            'snapshot.currentTask.detail' => 'sometimes|nullable|string|max:10000',
            'snapshot.currentTask.steps' => 'sometimes|array|max:255',
            'snapshot.currentTask.steps.*.name' => 'required|string|max:1000',
            'snapshot.currentTask.steps.*.detail' => 'sometimes|nullable|string|max:10000',
            'snapshot.currentTask.steps.*.objectiveType' => 'sometimes|integer|min:-128|max:255',
            'snapshot.currentTask.steps.*.mapId' => 'sometimes|integer|min:-1|max:65535',
            'snapshot.currentTask.steps.*.requiredCount' => 'sometimes|integer|min:-1|max:2147483647',
            ...collect(['bag', 'chest', 'equipped', 'collectionChest'])->flatMap(fn ($key) => [
                "snapshot.$key" => 'present|array|max:1000', "snapshot.$key.*.slot" => 'required|integer|min:0|max:10000',
                "snapshot.$key.*.templateId" => 'required|integer|min:0|max:100000',
                "snapshot.$key.*.quantity" => 'required|integer|min:1|max:1000000000',
                "snapshot.$key.*.options" => 'present|array|max:100',
                "snapshot.$key.*.options.*.optionId" => 'required|integer|min:0|max:100000',
                "snapshot.$key.*.options.*.param" => 'required|integer',
                "snapshot.$key.*.info" => 'nullable|string|max:4000', "snapshot.$key.*.content" => 'nullable|string|max:4000',
            ])->all(),
        ])->validate();

        // Explicit public projection: never persist arbitrary credential fields from a worker.
        $source = $payload['snapshot'];
        $data = Arr::only($source, ['capturedAt', 'disciple']);
        $skillFields = ['skillId', 'templateId', 'iconId', 'level', 'name', 'maxLevel', 'type', 'powerRequired', 'manaUse', 'cooldownMilliseconds', 'damage', 'moreInfo', 'currentExperience', 'manaUseType'];
        $data['skills'] = array_map(fn ($s) => Arr::only($s, $skillFields), $source['skills'] ?? []);
        $data['intrinsic'] = isset($source['intrinsic']) ? Arr::only($source['intrinsic'], ['iconId', 'info']) : null;
        $data['intrinsicOptions'] = array_map(fn ($o) => Arr::only($o, ['groupIndex', 'optionIndex', 'groupName', 'groupDescription', 'iconId', 'info']), $source['intrinsicOptions'] ?? []);
        $data['collectionBook'] = array_map(function ($e) {
            $entry = Arr::only($e, ['id', 'number', 'iconId', 'rank', 'amount', 'maxAmount', 'entryType', 'templateId', 'name', 'info', 'level', 'isUsed']);
            $entry['options'] = array_map(fn ($o) => Arr::only($o, ['optionId', 'param', 'activeLevel']), $e['options'] ?? []);
            return $entry;
        }, $source['collectionBook'] ?? []);
        $data['currentTask'] = isset($source['currentTask']) ? Arr::only($source['currentTask'], ['id', 'currentStep', 'name', 'detail', 'currentCount']) : null;
        if ($data['currentTask'] !== null && isset($source['currentTask']['steps'])) {
            $data['currentTask']['steps'] = array_map(fn ($step) => Arr::only($step, ['name', 'detail', 'objectiveType', 'mapId', 'requiredCount']), $source['currentTask']['steps']);
        }
        $data['character'] = Arr::only($source['character'], ['id', 'name', 'power', 'potential', 'hp', 'mp', 'hpMax', 'mpMax', 'hpBase', 'mpBase', 'damageBase', 'damage', 'armor', 'critical', 'gender', 'gold', 'gem', 'lockedGem', 'classId', 'head', 'task']);
        $groups = [];
        foreach (['equipped', 'bag', 'chest', 'collectionChest'] as $location) {
            $data[$location] = [];
            foreach ($source[$location] as $item) {
                $identity = self::identity($item);
                $enriched = $this->catalog->item([...$identity, 'slot' => $item['slot'], 'quantity' => $item['quantity']]);
                $data[$location][] = $enriched;
                if ($location === 'collectionChest') continue;
                $hash = hash('sha256', json_encode($identity, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                $groups[$hash] ??= ['item' => $enriched, 'quantity' => 0, 'locations' => []];
                $groups[$hash]['quantity'] += $item['quantity'];
                $groups[$hash]['locations'][] = ['location' => $location, 'slot' => $item['slot'], 'quantity' => $item['quantity']];
            }
        }
        if (is_array($data['disciple'] ?? null)) {
            $data['disciple'] = Arr::only($data['disciple'], ['exists', 'hasDetails', 'name', 'power', 'potential', 'hp', 'hpMax', 'mp', 'mpMax', 'damage', 'armor', 'critical', 'skills', 'equipped']);
            $data['disciple']['equipped'] = array_map(fn ($i) => $this->catalog->item([...self::identity($i), 'slot' => $i['slot'], 'quantity' => $i['quantity']]), $data['disciple']['equipped'] ?? []);
            $data['disciple']['skills'] = array_map(fn ($s) => Arr::only($s, $skillFields), $data['disciple']['skills'] ?? []);
        }
        $summary = ['character' => Arr::only($data['character'], ['name', 'power', 'gender']), 'serverIndex' => $account->server_index, 'serverId' => $account->server_id, 'serverName' => DB::table('servers')->where('id', $account->server_id)->value('name_view'),
            'capturedAt' => $source['capturedAt'], 'highlights' => array_slice($data['equipped'], 0, 6),
            'itemPreviews' => self::cardItemPreviews($data),
            'disciple' => is_array($data['disciple'] ?? null) ? Arr::only($data['disciple'], ['exists', 'hasDetails', 'name', 'power']) : null];
        $summary = array_replace($summary, NroCardSummary::fromData($data));
        return DB::transaction(function () use ($account, $payload, $data, $summary, $groups) {
            $account = NroAccount::whereKey($account->id)->lockForUpdate()->firstOrFail();
            $snapshot = NroAccountSnapshot::create(['account_id' => $account->id, 'schema_version' => 1,
                'catalog_version' => $payload['catalogVersion'], 'captured_at' => $data['capturedAt'],
                'data_json' => $data, 'summary_json' => $summary, 'completeness_json' => $payload['completeness']]);
            $previous=$account->latest_snapshot_id ? NroAccountSnapshot::find($account->latest_snapshot_id) : null;
            if($previous && $previous->captured_at->gt($snapshot->captured_at)) return $snapshot;
            // A partial chest response must never erase known stock or make partial inventory sellable.
            if (($payload['completeness']['bag'] ?? false) && ($payload['completeness']['chest'] ?? false) && ($payload['completeness']['equipped'] ?? false)) {
                DB::table('nro_inventory_items')->where('account_id', $account->id)->update(['quantity' => 0, 'updated_at' => now()]);
                foreach ($groups as $hash => $group) {
                    DB::table('nro_inventory_items')->updateOrInsert(['account_id' => $account->id, 'fingerprint' => $hash], [
                        ...NroItemFilters::inventoryColumns($group['item']),
                        ...NroItemFilters::extraInventoryColumns($group['item']),
                        'template_id' => $group['item']['templateId'], 'item_json' => json_encode($group['item']),
                        'locations_json' => json_encode($group['locations']), 'quantity' => $group['quantity'], 'updated_at' => now(),
                    ]);
                }
            }
            if ($payload['completeness']['bag'] && $payload['completeness']['chest'] && $payload['completeness']['equipped']) {
                if ($account->login_sale_blocked || $account->login_failure_kind) $account->update(['login_sale_blocked'=>false,'login_failure_kind'=>null]);
                DB::table('item_orders')->where('account_id',$account->id)->whereIn('failure_code',['login_failed','account_locked'])->where('failure_role','sender')->where('status','awaiting_receipt')->where('cancel_requested',false)->update(['failure_code'=>null,'failure_role'=>null,'public_failure'=>null,'login_retry_at'=>null,'delivery_message'=>'Acc kho đã được kiểm tra. Bạn có thể nhận tiếp.','updated_at'=>now()]);
                NroRoundRecovery::resumeAccount((int)$account->id);
                if ($account->publish_status === 'login_blocked') $account->update(['publish_status'=>null,'publish_error'=>null]);
            }
            if ($payload['completeness']['bag'] && $payload['completeness']['chest'] && $payload['completeness']['equipped'] && $account->publish_status === 'scan_failed') $account->update(['publish_status'=>null,'publish_error'=>null]);
            $account->update(['snapshot_failures' => ($payload['completeness']['bag'] && $payload['completeness']['chest'] && $payload['completeness']['equipped']) ? 0 : $account->snapshot_failures, 'latest_snapshot_id' => $snapshot->id, 'last_synced_at' => ($payload['completeness']['bag'] && $payload['completeness']['chest'] && $payload['completeness']['equipped']) ? $snapshot->captured_at : null, 'character_name' => $data['character']['name']]);
            if ($payload['completeness']['bag'] && $payload['completeness']['chest'] && $payload['completeness']['equipped']) {
                foreach(DB::table('item_orders')->where('account_id',$account->id)->where('failure_code','missing_items')->where('status','awaiting_receipt')->where('cancel_requested',false)->get() as $order) {
                    $enough=true;
                    foreach(DB::table('item_order_items')->where('order_id',$order->id)->get() as $line) {
                        $inventory=DB::table('nro_inventory_items')->find($line->inventory_item_id);
                        $others=DB::table('item_inventory_reservations')->where('inventory_item_id',$line->inventory_item_id)->where('order_id','!=',$order->id)->where('status','held')->sum('quantity');
                        if(!$inventory || $inventory->quantity-$others < $line->quantity-$line->delivered) { $enough=false; break; }
                    }
                    if($enough) DB::table('item_orders')->where('id',$order->id)->update(['failure_code'=>null,'public_failure'=>null,'refund_requested'=>false,'delivery_message'=>'Kho đã bổ sung đủ đúng vật phẩm. Bạn có thể nhận tiếp.','updated_at'=>now()]);
                }
            }
            NroSellerPolicy::refreshAccounts([$account->id]);
            \App\Support\ApiCache::clearGroup('public:nro-shop:listings');
            return $snapshot;
        });
    }
}
