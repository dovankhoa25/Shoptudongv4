<?php

namespace App\Services;

use App\Models\NroAccount;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class NroReceivingService
{
    public function start(User $user, int $id, array $v): int
    {
        if ($v['mode'] === 'manual') $v['recipientName'] = mb_strtolower(trim($v['recipientName']), 'UTF-8');
        return DB::transaction(function () use ($user, $id, $v) {
            // Lock the buyer first, matching purchase lock ordering.
            User::whereKey($user->id)->lockForUpdate()->firstOrFail();
            $o = DB::table('item_orders')->where('id', $id)->where('buyer_id', $user->id)->first();
            abort_unless($o, 404);
            $a = NroAccount::whereKey($o->account_id)->lockForUpdate()->firstOrFail();
            $o = DB::table('item_orders')->where('id', $id)->lockForUpdate()->first();
            $old = DB::table('nro_delivery_sessions')->where(['order_id' => $id, 'request_key' => $v['requestKey']])->first();
            if ($old) { NroShopService::require($this->sameRequest($old,$v), 'Mã yêu cầu đã thuộc cách nhận khác.'); return $old->id; }
            $active=DB::table('nro_delivery_sessions')->where('order_id',$id)->whereIn('status',NroOrderFlow::ACTIVE_SESSIONS)->latest('id')->first();
            if ($active) { NroShopService::require($this->sameRequest($active,$v), 'Yêu cầu nhận hiện tại đang chạy. Chờ kết thúc trước khi đổi người hoặc cách nhận.'); return $active->id; }
            NroShopService::require(!DB::table('nro_worker_jobs')->where('account_id',$a->id)->whereNotNull('audit_order_id')->whereIn('status',['queued','processing'])->exists(), 'Shop đang kiểm tra tồn kho; vui lòng chờ kiểm tra xong rồi nhận đồ.');
            NroShopService::require(!$o->cancel_requested, 'Đơn đang chờ hủy và hoàn tiền.');
            NroShopService::require($o->failure_code !== 'missing_items', 'Kho thiếu đồ. Chờ shop bổ sung và kiểm tra lại kho.');
            NroShopService::require($o->status === 'awaiting_receipt', 'Đơn đang nhận đồ hoặc cần đối soát.');
            NroShopService::require(!NroRoundRecovery::pending((int)$o->id),'Bot đang khôi phục lượt giao trước; không cần tạo phiên nhận khác.');
            NroShopService::require($a->status === 'active' && $a->server_id && $a->server_game_id, 'Kho cần được cấu hình server hiển thị và server đăng nhập.');
            if($a->publish_status==='login_blocked') {
                $locked=$a->login_failure_kind==='AccountLocked';
                DB::table('item_orders')->where('id',$id)->update(['failure_role'=>'sender','failure_code'=>$locked ? 'account_locked' : 'login_failed','public_failure'=>$locked ? 'Acc kho bị game khóa. Bạn có thể yêu cầu hủy nếu chưa nhận món nào.' : 'Acc kho chưa thể đăng nhập. Chờ shop xử lý để tiếp tục giao đồ.','delivery_message'=>'Kho chưa thể đăng nhập.','updated_at'=>now()]);
                return 0;
            }
            NroShopService::require(!DB::table('nro_delivery_sessions')->where('order_id', $id)->whereIn('status', ['queued', 'preparing', 'ready', 'trading', 'review'])->exists(), 'Đơn đã có phiên nhận.');
            $cooldown = DB::table('nro_delivery_sessions')->where('order_id', $id)->where('retry_at', '>', now())->max('retry_at');
            NroShopService::require(!$cooldown, 'Phiên nhận bị tạm dừng do quá thời gian giao dịch. Vui lòng đợi hết thời gian chờ rồi nhận lại.');
            $credentials = null;
            $lock = null;
            if ($v['mode'] === 'auto') {
                $username = trim($v['username']);
                NroShopService::require(!NroAccount::withTrashed()->where('server_game_id', $a->server_game_id)->whereRaw('LOWER(account_name) = ?', [mb_strtolower($username)])->exists(), 'Acc nhận không được là acc do hệ thống quản lý.');
                $lock = hash('sha256', $a->server_game_id . ':' . mb_strtolower($username));
                DB::table('nro_receiver_locks')->insertOrIgnore(['key'=>$lock]);
                DB::table('nro_receiver_locks')->where('key',$lock)->lockForUpdate()->first();
                NroShopService::require(!DB::table('nro_delivery_sessions as s')->join('item_orders as o','o.id','=','s.order_id')
                    ->where('s.receiver_lock',$lock)->whereIn('s.status',NroOrderFlow::ACTIVE_SESSIONS)
                    ->where(fn($q)=>$q->where('o.account_id','!=',$a->id)->orWhere('o.buyer_id','!=',$user->id))->exists(),
                    'Acc nhận đang được dùng với kho hoặc người mua khác. Hoàn tất phiên đó trước.');
                $credentials = app(NroCredentialCipher::class)->encryptString(json_encode(['username' => $username, 'password' => $v['password']]));
            }
            $session = DB::table('nro_delivery_sessions')->insertGetId([
                'order_id' => $id,
                'request_key' => $v['requestKey'],
                'mode' => $v['mode'],
                'status' => 'queued',
                'trade_in_flight' => false,
                'recipient_name' => $v['mode'] === 'manual' ? $v['recipientName'] : null,
                'receiver_credentials' => $credentials,
                'receiver_lock' => $lock,
                'wait_minutes' => $a->wait_minutes,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            DB::table('item_orders')->where('id', $id)->update(['failure_role'=>null,'failure_code'=>null,'public_failure'=>null,'login_retry_at'=>null,'refund_requested'=>false,'status' => 'queued', 'delivery_message' => 'Đã yêu cầu nhận đồ; đang chờ tool.', 'updated_at' => now()]);
            DB::table('nro_worker_jobs')->insert(['account_id' => $a->id, 'order_id' => $id, 'delivery_session_id' => $session, 'type' => 'delivery', 'status' => 'queued', 'created_at' => now(), 'updated_at' => now()]);
            return $session;
        }, 3);
    }

    private function sameRequest(object $session,array $v): bool {
        if ($session->mode !== $v['mode']) return false;
        if ($v['mode']==='manual') return mb_strtolower(trim($v['recipientName']), 'UTF-8') === mb_strtolower(trim($session->recipient_name), 'UTF-8');
        if (!$session->receiver_credentials) return true;
        $login=json_decode(app(NroCredentialCipher::class)->decryptString($session->receiver_credentials),true);
        return trim($v['username']) === $login['username'] && hash_equals($login['password'],$v['password']);
    }

    public function retryInterrupted(object $job, ?string $message = null): bool
    {
        if (!$job->order_id || !$job->delivery_session_id) return false;
        if (NroOrderFlow::terminal((string)DB::table('item_orders')->where('id',$job->order_id)->value('status'))) return false;
        $session = DB::table('nro_delivery_sessions')->where('id', $job->delivery_session_id)->lockForUpdate()->first();
        if (!$session || $session->trade_in_flight === null || (bool) $session->trade_in_flight) return false;
        if (!DB::table('item_order_items')->where('order_id', $job->order_id)->whereColumn('delivered', '<', 'quantity')->exists()) return false;
        DB::table('item_orders')->where('id', $job->order_id)->update([
            'status' => 'awaiting_receipt',
            'delivery_message' => $message ?: 'Phiên nhận đã dừng trước khi giao dịch hoặc sau lượt đã xác nhận. Đồ còn lại vẫn được giữ; bấm Nhận đồ để tiếp tục, không thanh toán lại.',
            'updated_at' => now(),
        ]);
        $this->finish($job, 'failed');
        DB::table('nro_worker_jobs')->where('id', $job->id)->update([
            'status' => 'failed',
            'result_json' => json_encode(['retrySafe' => true, 'message' => $message ?: 'Dừng ngoài giao dịch chưa xác nhận.']),
            'updated_at' => now(),
        ]);
        return true;
    }

    public function finish(object $job, string $status): void
    {
        NroWarehouseActivity::releasePreparation($job);
        if (!$job->delivery_session_id) return;
        DB::table('nro_delivery_sessions')->where('id', $job->delivery_session_id)->update([
            'status' => $status,
            'receiver_credentials' => ($status === 'review' || NroRoundRecovery::pending((int)$job->order_id)) ? DB::raw('receiver_credentials') : null,
            // Keep the login lock on uncertain results until reconciliation.
            'receiver_lock' => ($status === 'review' || NroRoundRecovery::pending((int)$job->order_id)) ? DB::raw('receiver_lock') : null,
            'updated_at' => now(),
        ]);
    }
}
